# JIANXIN | 지안신(簡信)

面向韩国企业的韩文官网。使用原生 HTML、CSS、JavaScript 和原创 SVG，无第三方运行依赖或外部字体、图片请求。

## 本地开发

使用 Node.js 20 或更高版本：

Windows 操作步骤：

1. 安装 Node.js LTS（建议 24，最低 20），安装时保留 npm 并添加到 PATH。
2. 解压完整项目，例如 `C:\Projects\jianxin-website`，不要直接在 ZIP 内编辑。
3. 在项目文件夹打开 PowerShell，执行：

```powershell
cd C:\Projects\jianxin-website
npm.cmd run check
npm.cmd start
```

4. 浏览器打开 `http://localhost:3000`。修改文件并保存后刷新页面。
5. 在终端按 `Ctrl+C` 停止服务。

项目没有第三方依赖，因此不需要执行 `npm install`。使用 `npm.cmd` 可避免 PowerShell 对 npm.ps1 的执行策略限制。

若端口 3000 被占用，在 PowerShell 中执行：

```powershell
$env:PORT = "3001"
npm.cmd start
```

然后打开 `http://localhost:3001`。若命令提示找不到 Node.js 或 npm，请安装 Node.js 后重新打开终端。

macOS / Linux：在解压后的项目目录执行 `npm start`。

默认监听端口 3000，可通过 `PORT` 环境变量调整。修改页面后刷新浏览器即可。`npm run check` 检查 JavaScript 语法。

## 文件

- `index.html`：韩文内容、SEO 元信息、原创贸易主题 SVG
- `style.css`：响应式布局、动效及减少动画偏好支持
- `app.js`：移动菜单、邮箱复制、滚动入场
- `server.mjs`：本地静态服务器
- `favicon.svg`：原创网站图标
- `package.json`：启动、开发、页面生成、检查及测试命令
- `categories/`：八个商品分类静态详情页
- `services/`：四个采购服务静态详情页
- `assets/`：八张原创商品分类示例 SVG，不表示实际商品或库存
- `data/catalog.mjs`：分类和服务的可扩展内容数据
- `scripts/build-pages.mjs`：统一生成详情页和首页分类卡片
- `scripts/check-site.mjs`：本地 HTTP、链接和资源集成测试
- `backups/`：本机修改前备份与验收截图，已被 Git 忽略，不通过网站服务器公开

页面的大幅贸易插画与服务图标直接内嵌在 `index.html` 中，无需额外下载图片。CSS 使用系统字体，不依赖外部字体服务。项目无第三方依赖，因而没有依赖锁文件。ZIP 不包含 `.git` 历史或本机配置，包含完整网站源代码。

所有文本文件采用 UTF-8，请在编辑器中保留此编码，避免韩文乱码。

## 联系与内容

邮件咨询发送至 `ywjianxin@163.com`，打开访客邮件客户端；网站不采集或存储表单信息。Email、KakaoTalk（`multiflora23`）、WeChat（`Oliiiii_20`）均支持复制，在安全上下文可用，不可用时显示手动复制提示。不展示未经提供的二维码。文案没有虚构客户、历史、规模或业绩。服务范围和费用需单独协商。

## 部署

如未来授权部署，应同时包含 `index.html`、`style.css`、`app.js`、`favicon.svg`、`assets/`、`categories/` 和 `services/`。当前生成的详情页已保存在项目中，正常启动无需构建。正式上线请使用 HTTPS，并由公司确认文案、服务范围及适用的企业展示要求；当前未配置正式域名或公开部署。


## 第二轮优化与后续维护

- Logo：已接入用户提供的深蓝底、白色 JX、环绕线和星光原图，页头和页脚通过 CSS 展示字母图形，旁边保留统一公司名称；未仿画或重绘。favicon 仍为临时文字图标。
- 实景图：当前版本原本没有四张实景照片。现预留两个图片位，分别为“이우 국제상무성”和“공장 소싱 현장”，清楚标注真实照片准备中。请提供已获使用权的明亮自然建筑照片及工厂采购照片后再替换，不将图库或生成画面宣称为真实公司现场。
- 首页保留三个优势和四个采购步骤；电脑端为横向时间线，手机端转为纵向以便阅读。
- 全站涉及义乌的韩文统一使用“이우”。商品页仅提供分类介绍、示例插画和询价，不承诺库存、价格或认证；食品接触类、儿童用品不作为主动推广类别，其他商品也须逐项确认韩国进口要求。
- 正式预览请通过 `npm.cmd start` 启动。不要依赖双击 HTML 文件时的剪贴板能力。

### 新增或修改详情页

1. 编辑 `data/catalog.mjs` 中的 `categories` 或 `services` 数组，为新项目设置唯一的小写英文 `slug`。
2. 新分类需在 `assets/` 添加同名 SVG，例如 `new-category.svg`（使用原创或授权素材）。
3. 运行以下命令，并一并保存生成的 HTML：

```powershell
npm.cmd run pages
npm.cmd run check
npm.cmd test
```

分类卡片和所有详情页由同一份数据生成。采购服务首页卡片在 `index.html` 中维护；新增服务时请同步添加入口。`scripts/build-pages.mjs` 是详情页模板，不要仅编辑会被覆盖的生成页面。删除条目时请单独检查旧页面与链接，生成器不会删除文件。

### 本地备份

第二轮修改前的完整源文件归档位于 `backups/before-round-2-20261029T093551Z.zip`。该备份已验证完整，包含此前七个项目文件。解压到另一个文件夹即可查看旧版；不要直接覆盖当前工作。`backups/` 不加入 Git，需在 Windows 上另行保存重要备份。

### 验证范围

`npm.cmd test` 启动临时本地服务并验证全部 13 个韩文页面、站内链接与资源、联系信息及非公开路径限制。浏览器布局和交互验收另在 Linux Chromium 中执行；没有实际 Windows 机器的验收结果。Node.js 路径判断已使用跨平台 API，PowerShell 启动命令保留。

## Logo 与真实二维码（已接入）

用户于 2026-10-30 提供的 ZIP 已验证完整。以下文件直接提取至 `assets/`，与 ZIP 中原图逐字节一致：

- `jianxin-logo.png`：1254 × 1254，深蓝底白色 JX、环绕线和星光。
- `wechat-qr.jpg`：888 × 1131，微信原始二维码卡片。
- `kakao-qr.jpg`：750 × 925，KakaoTalk 原始二维码卡片。
- `site-images.js`：全站图片文件名配置，首页及详情页共用。

网页通过 CSS 仅调整原图的展示窗口，隐藏二维码截图的头像、卡通和多余文案；不修改原文件、不重新生成或重绘二维码。卡片统一浅蓝白色，二维码保留黑白及边缘留白，Logo 保留原图深蓝色。

二维码显示窗口分别使用 `.qr-wechat`、`.qr-kakao`，Logo 使用 `.brand-image-slot`。后续替换不同尺寸或构图的截图时，应重新核对 CSS 裁切位置。加载失败时保留占位与可复制联系 ID。

已检查真实图片加载、桌面和手机布局以及全站链接。真实微信和 KakaoTalk 应用的加好友结果仍需人工扫码确认；浏览器显示检查不等同于账号可添加性验证。

接入前备份：`backups/before-original-assets-20261030T062009Z.zip`。验收截图：`backups/validation-originals/`。
